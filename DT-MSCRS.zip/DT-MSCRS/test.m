function [Sfinal]=test(X,alpha,beta,gamma,lambda1,lambda2)

N=size(X{1},2);
V=size(X,1);
epson = 1e-7;

for v = 1:V
    Z{v} = zeros(N,N);
    E1{v} = zeros(size(X{v},1),N);
    E2{v} = zeros(size(X{v},1),N);
    J{v} = zeros(N,N);
    W{v} = zeros(N,N); 
    K{v} = zeros(N,N);
    S{v} = zeros(N,N);
    Y1{v} = zeros(size(X{v},1),N);
    Y2{v} = zeros(N,N);
    Y3{v} = zeros(N,N);
    Y4{v} = zeros(N,N);
    Y5{v} = zeros(N,N);
end

Sfinal=zeros(N,N);

for v=1:V
A{v} = constructW_PKN(X{v},10);   
D{v}=diag(sum(A{v}));
L{v}=D{v}-A{v};
end

I = eye(N);
sX = [N, N, V];
mu = 0.1;
mu_max = 10e10;

eta2 = 2;
converge_Z=[]; converge_Z_J=[];

Isconverg = 0;
iter = 1;

while(Isconverg == 0)


    J_tensor = cat(3, J{:,:});
    Y3_tensor = cat(3, Y3{:,:});
    j = J_tensor(:);
    y3 = Y3_tensor(:);
    [j, ~] = wshrinkObj(j+1/mu*y3,1/mu,sX,0,3);
    J_tensor = reshape(j, sX);
    for v=1:V
        J{v} = J_tensor(:,:,v);
    end


    K_tensor = cat(3, K{:,:});
    Y5_tensor = cat(3, Y5{:,:});
    k = K_tensor(:);
    y5 = Y5_tensor(:);
    [k, ~] = wshrinkObj(k+1/mu*y5,beta/mu,sX,0,3);
    K_tensor = reshape(k, sX);
    for v=1:V
        K{v} = K_tensor(:,:,v);
    end


    for v=1:V
        F1 = (X{v}-X{v}*Z{v}+Y1{v}./mu);
        E1{v} = solve_l1l2(F1,alpha./mu);
    end
    


    for v=1:V
        F2 = (W{v}-S{v}+Y2{v}./mu);
        E2{v} = solve_l1l2(F2,gamma./mu);
    end



    for v = 1:V
        Z{v}=inv(X{v}'*X{v}+2.*I)*(X{v}'*(X{v}+E1{v}-Y1{v}./mu)+(J{v}-Y3{v}./mu)+(W{v}-Y4{v}./mu));
    end


    for v= 1:V
       for q=1:V
           if q==v
               continue
           end
            S{v}=inv(2.*I+2.*lambda1./mu.*I+2.*lambda2./mu.*L{v})*(W{v}+K{v}-E2{v}+2.*lambda1./mu.*S{q}+Y2{v}./mu+Y5{v}./mu);
            
       end
    end



    for v = 1:V
        W{v}=inv(2*mu.*I)*(mu.*S{v}+mu.*E2{v}+mu.*Z{v}-Y2{v}+Y4{v});
    end


    for v=1:V
        Y1{v} = Y1{v}+mu*(X{v}-X{v}*Z{v}-E1{v});
    end


    for v=1:V
        Y2{v} = Y2{v}+mu*(W{v}-S{v}-E2{v});
    end


    for v=1:V
        Y3{v} = Y3{v}+mu*(Z{v}-J{v});
    end


    for v=1:V
        Y4{v} = Y4{v}+mu*(Z{v}-W{v});
    end


    for v=1:V
        Y5{v} = Y5{v}+mu*(S{v}-K{v});
    end



    B = zeros(N,N);
    for v = 1:V
        B = B+S{v};
    end

    Sfinal = B/V;


    max_Z=0;
    max_Z_J=0;
    Isconverg = 1;
    for k = 1:V

        if (norm(X{k} - X{k} * Z{k} - E1{k}, inf) > epson)
            history.norm_Z = norm(X{k} - X{k} * Z{k} - E1{k}, inf);
            Isconverg = 0;
            max_Z = max(max_Z, history.norm_Z);

        end

        if (norm(Z{k} - J{k}, inf) > epson)
            history.norm_Z_J = norm(Z{k} - J{k}, inf);
            Isconverg = 0;
            max_Z_J = max(max_Z_J, history.norm_Z_J);
        end

    

    end



    converge_Z=[converge_Z max_Z];
    converge_Z_J=[converge_Z_J max_Z_J];
   



    mu  = min(mu_max,mu*eta2);
    iter = iter + 1;
    if (iter==50)
        Isconverg = 1;
    end

end
