addpath('datasets/','fun/');

load("MSRCV1.mat");
for i=1:6
    X{i}=X{i}';
end
gt = Y; 
class_num = length(unique(gt)); 

alpha=10;
beta=0.001;
gamma=1;
lambda1=0.1;
lambda2=0.001;

test_num = 10;
result = [];

for i = 1:test_num
    [Sfinal] = test(X,alpha,beta,gamma,lambda1,lambda2);
    Y1 = Ng_SpectralClustering(Sfinal*Sfinal',class_num);
    [ACC,NMI,PUR] = ClusteringMeasure(gt,Y1);
    [Fscore,Precision,R] = compute_f(gt,Y1);
    [AR,~,~,~]=RandIndex(gt,Y1);
    
    result(i,:) = [ACC, NMI, PUR, Fscore, AR];
end

me = mean(result, 1);
st = std(result, 1);

fprintf(' ACC     = %.4f ± %.4f\n', me(1), st(1));